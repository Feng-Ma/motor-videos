from .motor_videos import MotorVideos
from .flujo_semanal import FlujoSemanal

__all__ = ["MotorVideos", "FlujoSemanal"]
